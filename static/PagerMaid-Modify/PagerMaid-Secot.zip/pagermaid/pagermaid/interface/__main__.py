""" PagerMaid web interface startup. """

from pagermaid import logs

logs.info("出错了呜呜呜 ~ 此模块不应直接运行。")
